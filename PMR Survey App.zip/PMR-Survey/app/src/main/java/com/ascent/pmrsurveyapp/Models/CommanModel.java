package com.ascent.pmrsurveyapp.Models;

public class CommanModel {

    public String id, name;

    public CommanModel(){}

    public CommanModel(String id, String name) {
        this.id = id;
        this.name = name;
    }
}
