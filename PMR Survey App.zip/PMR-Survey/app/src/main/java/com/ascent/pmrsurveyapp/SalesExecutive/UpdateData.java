package com.ascent.pmrsurveyapp.SalesExecutive;

public interface UpdateData {
    void reloadTheData();
}
