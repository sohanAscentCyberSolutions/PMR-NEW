package com.ascent.pmrsurveyapp.Fragments;


import com.ascent.pmrsurveyapp.Models.CommanModel;

public interface ItemSelecter {
    void itemSelected(CommanModel selectedItem , int requestCode);
}
