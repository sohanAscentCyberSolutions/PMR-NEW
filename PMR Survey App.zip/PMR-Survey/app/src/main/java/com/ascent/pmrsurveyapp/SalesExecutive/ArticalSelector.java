package com.ascent.pmrsurveyapp.SalesExecutive;

import com.ascent.pmrsurveyapp.SalesExecutive.Modals.StandardItemsModel;

public interface ArticalSelector {
    void articalSelected(StandardItemsModel data);
}
